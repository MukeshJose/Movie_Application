package com.example.movieapplication.model;

import java.util.ArrayList;

public class Root {
    public int page;
    public ArrayList<Result> results;
    public int total_pages;
    public int total_results;
}
